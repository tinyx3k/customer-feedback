<?php

require_once '../../../wp-config.php';
try {
	$user_id = base64_decode(@$_POST['user_id']);
	$title = @$_POST['title'];
	$body = @$_POST['body'];
	$post_name = @$_POST['post_name'];
	$wp_email = @$_POST['email'];
	$request = @$_POST['request'];

	if (class_exists('trafficgeniuspro')) {
		if ($request == 'post_article') {
			$page = trafficgeniuspro_create_post(compact('title', 'body', 'post_name', 'wp_email'), $user_id);
			$status = true;
			return wp_send_json(compact('page', 'status'));
		} else if ($request == 'validate') {
			$result = trafficgeniuspro_validate($wp_email);
			if (!$result) {
				throw new \Exception("Wordpress email doesn't exist.", 1);
			}
			else {
				$status = true;
				return wp_send_json(compact('result', 'status'));
			}
		}

	} else {
		throw new Exception("Plugin not active", 1);
	}

} catch (Exception $e) {
	$error = $e->getMessage();
	return wp_send_json(compact('error'));
}
