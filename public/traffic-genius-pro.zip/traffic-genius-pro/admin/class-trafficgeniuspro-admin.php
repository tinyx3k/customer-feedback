<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://trafficgeniuspro.com/
 * @since      1.0.0
 *
 * @package    trafficgeniuspro
 * @subpackage trafficgeniuspro/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    trafficgeniuspro
 * @subpackage trafficgeniuspro/admin
 * @author     trafficgeniuspro <admin@trafficgeniuspro.com>
 */
class trafficgeniuspro_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;



    /**
     * The array of templates that this plugin tracks.
     */
    protected $templates;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct($plugin_name, $version) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

		//  handle the homepage product list order
		add_action('admin_post_trafficgeniuspro_account', [$this, 'post_trafficgeniuspro_account']);
		add_action('admin_post_trafficgeniuspro_sync_pages', [$this, 'post_trafficgeniuspro_sync_pages']);
		add_action('admin_post_trafficgeniuspro_logout', [$this, 'post_trafficgeniuspro_logout']);
		add_action('save_post', [$this, 'save_post_to_saas']);
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in trafficgeniuspro_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The trafficgeniuspro_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		if (isset($_GET['page']) && preg_match("~\btraffic-genius-pro\b~", $_GET['page'])):
			wp_enqueue_style($this->plugin_name . '-bootstrap', plugin_dir_url(__FILE__) . '../vendor/bootstrap/css/bootstrap.min.css', array(), $this->version, 'all');
		endif;

		wp_enqueue_style($this->plugin_name . '-font-awesome', plugin_dir_url(__FILE__) . '../vendor/font-awesome/css/font-awesome.min.css', array(), $this->version, 'all');

		wp_enqueue_style($this->plugin_name . '-select2', plugin_dir_url(__FILE__) . '../vendor/select2/css/select2.min.css', array(), $this->version, 'all');

		wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/traffic-genius-pro-admin.css', array(), $this->version, 'all');

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in trafficgeniuspro_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The trafficgeniuspro_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script('jQuery');

		wp_enqueue_script($this->plugin_name . '-bootstrap', plugin_dir_url(__FILE__) . '../vendor/bootstrap/js/bootstrap.min.js', array(), $this->version, false);

		wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/traffic-genius-pro-admin.js', array('jquery'), $this->version, false);

		wp_localize_script($this->plugin_name, 'updateOrCreateUrl', array(
			'ajax_url' => admin_url('admin-ajax.php'),
		));

	}

	public function add_plugin_admin_menu() {

		/*
			     * Add a settings page for this plugin to the Settings menu.
			     *
			     * NOTE:  Alternative menu locations are available via WordPress administration menu functions.
			     *
			     *        Administration Menus: http://codex.wordpress.org/Administration_Menus
			     *
		*/

		add_menu_page('Traffic Genius Pro Setup', 'Traffic Genius Pro', '', $this->plugin_name);

		add_submenu_page($this->plugin_name, 'Traffic Genius Pro', 'Account', 'manage_options', $this->plugin_name. '-account', array($this, 'display_plugin_trafficgeniuspro_setup_page'));

		// wp_enqueue_media();

		remove_filter('the_content', 'wpautop');

		add_action('wp_ajax_post_update_or_create', [$this, 'post_update_or_create']);
	}

	/**
	 * Add settings action link to the plugins page.
	 *
	 * @since    1.0.0
	 */

	public function add_action_links($links) {
		/*
			    *  Documentation : https://codex.wordpress.org/Plugin_API/Filter_Reference/plugin_action_links_(plugin_file_name)
		*/
		$settings_link = array(
			'<a href="' . admin_url('admin.php?page=' . $this->plugin_name . '-account') . '">' . __('Account', $this->plugin_name) . '</a>',
		);
		return array_merge($settings_link, $links);

	}

	/**
	 * Render the settings page for this plugin.
	 *
	 * @since    1.0.0
	 */
	public function display_plugin_setup_page() {
		include_once 'partials/account/trafficgeniuspro-admin-display.php';
	}

	/**
	 * Render the settings hompage page for this plugin.
	 *
	 * @since    1.0.0
	 */
	public function display_plugin_trafficgeniuspro_setup_page() {
		include_once 'partials/account/trafficgeniuspro-admin-display.php';
	}

	public function add_meta_host_url_on_head() {
		echo '<meta name="host" value="">';
	}

	/**
	 * handle the slider update or create form
	 *
	 */
	public function post_trafficgeniuspro_account() {

		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}

		$redirect_url = sanitize_text_field(isset($_POST['redirect_url']) ? $_POST['redirect_url'] : '');

		$return = save_trafficgeniuspro_account($_POST);

		session_start();
		if ($return['status']) {
			$_SESSION['trafficgeniuspro_message'] = ['message' => $return['message'], 'type' => 'success', 'header' => 'Well done!'];
		} else {
			$_SESSION['trafficgeniuspro_message'] = ['message' => $return['message'], 'type' => 'danger', 'header' => 'Oh snap!'];
		}

		wp_redirect($redirect_url);
		return;

	} // post_trafficgeniuspro_settings()

	public function post_trafficgeniuspro_sync_pages() {

		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}

		$redirect_url = sanitize_text_field(isset($_POST['redirect_url']) ? $_POST['redirect_url'] : '');

		$trafficgeniuspro_setting = get_trafficgeniuspro_account();
		global $trafficgeniuspro_account_option_name;
		// update_option($trafficgeniuspro_account_option_name, []);
		$raw_pages = get_pages();
		$pages = [];
		$counter = 0;
		foreach ($raw_pages as $key => $page) {
			$pages[$counter]['author'] 	= get_the_author_meta('display_name',$page->post_author);
			$pages[$counter]['body'] 	= $page->post_content;
			$pages[$counter]['post_id'] = $page->ID;
			$pages[$counter]['title'] 	= $page->post_title;
			$pages[$counter]['url'] 	= get_page_link($page->ID);
			$pages[$counter]['user_id'] = $trafficgeniuspro_setting['user_id'];
			$counter++;
		}

		$raw_post = get_posts();
		foreach ($raw_post as $key => $post) {
			$pages[$counter]['author'] 	= get_the_author_meta('display_name',$post->post_author);
			$pages[$counter]['body'] 	= $post->post_content;
			$pages[$counter]['post_id'] = $post->ID;
			$pages[$counter]['title'] 	= $post->post_title;
			$pages[$counter]['url'] 	= get_page_link($post->ID);
			$pages[$counter]['user_id'] = $trafficgeniuspro_setting['user_id'];
			$counter++;
		}

		$return = sync_trafficgeniuspro_pages($trafficgeniuspro_setting, $pages);

		session_start();
		if ($return['status']) {
			$_SESSION['trafficgeniuspro_message'] = ['message' => 'Sync successful.', 'type' => 'success', 'header' => 'Well done!'];
		} else {
			$_SESSION['trafficgeniuspro_message'] = ['message' => $return['message'], 'type' => 'danger', 'header' => 'Oh snap!'];
		}

		wp_redirect($redirect_url);
		return;

	} // post_trafficgeniuspro_settings()

	public function post_trafficgeniuspro_logout() {
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}

		$redirect_url = sanitize_text_field(isset($_POST['redirect_url']) ? $_POST['redirect_url'] : '');
		global $trafficgeniuspro_account_option_name;
		update_option($trafficgeniuspro_account_option_name, []);

		session_start();
		if ($return['status']) {
			$_SESSION['trafficgeniuspro_message'] = ['message' => 'Log-out successful.', 'type' => 'success', 'header' => 'Well done!'];
		} else {
			$_SESSION['trafficgeniuspro_message'] = ['message' => $return['message'], 'type' => 'danger', 'header' => 'Oh snap!'];
		}

		wp_redirect($redirect_url);
		return;
	}

	function save_post_to_saas( $post_id ) {
		// If this is just a revision, don't send the email.
		if ( wp_is_post_revision( $post_id ) )
			return;

		$trafficgeniuspro_setting = get_trafficgeniuspro_account();
		global $trafficgeniuspro_account_option_name;
		// update_option($trafficgeniuspro_account_option_name, []);
		$raw_pages = get_post($post_id);

		// dd($raw_pages);
		if ($raw_pages->post_status == 'publish') {
			$pages = [];
			$counter = 0;
			$pages[$counter]['author'] 	= get_the_author_meta('display_name',$raw_pages->post_author);
			$pages[$counter]['body'] 	= $raw_pages->post_content;
			$pages[$counter]['post_id'] = $raw_pages->ID;
			$pages[$counter]['title'] 	= $raw_pages->post_title;
			$pages[$counter]['url'] 	= get_page_link($raw_pages->ID);
			$pages[$counter]['user_id']	= $trafficgeniuspro_setting['user_id'];
			$return = sync_trafficgeniuspro_pages($trafficgeniuspro_setting, $pages, false);
		}

	}

} // class trafficgeniuspro_Admin
