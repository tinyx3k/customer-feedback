<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://app.trafficgeniuspro.com/
 * @since      1.0.0
 *
 * @package    trafficgeniuspro
 * @subpackage trafficgeniuspro/admin
 */

/**
 * option name for the trafficgeniuspro account
 */
global $trafficgeniuspro_account_option_name;
$trafficgeniuspro_account_option_name = 'trafficgeniuspro_account_option_name';

/**
 * save trafficgeniuspro best sellers as an wp option
 *
 * @param  array  $post - post data
 * @return array
 */

require 'vendor/autoload.php';
use \Httpful\Request;
function save_trafficgeniuspro_account(array $post = []) {

	if (!$post || empty($post)) {
		throw new Exception("Error Processing Request");
	}

	try {
		//verify user in ibootify server
		$url = 'http://app.trafficgeniuspro.com/api/login';
		$body = [
			'email' 	=> $post['username'],
			'password' 	=> $post['password'],
			'wp_site'	=> get_site_url(),
			'wp_email'	=> wp_get_current_user()->user_email
		];
		$response = Request::post($url)
			->sendsJson()
			->body(json_encode($body))
			->send();
		$response = json_decode($response);

		if (isset($response->error)) {
			$status = false;
			$message = $response->error;
		} else {
			if (isset($response->user_id)) {
				//save details
				global $trafficgeniuspro_account_option_name;
				$trafficgeniuspro_account = [];
				$trafficgeniuspro_account['username'] = (isset($post['username']) ? $post['username'] : '');
				$trafficgeniuspro_account['password'] = (isset($post['password']) ? $post['password'] : '');
				$trafficgeniuspro_account['user_id'] = $response->user_id;

				update_option($trafficgeniuspro_account_option_name, $trafficgeniuspro_account);
				$status = true;
				$message = 'Authentication Success.';
			} else {
				$message = 'Internal Server Error.';
				if ($response->error) {
					$message = $response->error;
				}
				$status = false;
			}
		}

	} catch (Exception $e) {
		$status = false;
		$message = $e->getMessage();
	}

	return compact('status', 'message');

} //save_trafficgeniuspro_account()

function sync_trafficgeniuspro_pages(array $trafficgeniuspro_account, array $pages, $validate = true) {

	if (!$trafficgeniuspro_account || empty($trafficgeniuspro_account)) {
		throw new Exception("Error Processing Request");
	}

	try {

		$url = 'http://app.trafficgeniuspro.com/api/sync-pages';
		$data = [];
		$data['email'] = $trafficgeniuspro_account['username'];
		$data['password'] = $trafficgeniuspro_account['password'];
		$data['pages'] = $pages;
		$data['validate'] = $validate;
		$body = json_encode($data);
		$response = Request::post($url)
			->sendsJson()
			->body($body)
			->send();
		$response = json_decode($response);

		if (isset($response->error)) {
			$status = false;
			$message = $response->error;
		} else {
			$status = true;
			$message = 'Sync Success.';
		}

	} catch (Exception $e) {
		$status = false;
		$message = $e->getMessage();
	}

	return compact('status', 'message');

} //save_trafficgeniuspro_account()

/**
 * get the trafficgeniuspro best sellers
 *
 * @return array|false
 */
function get_trafficgeniuspro_account() {

	global $trafficgeniuspro_account_option_name;

	$trafficgeniuspro_account = get_option($trafficgeniuspro_account_option_name);

	if (!$trafficgeniuspro_account) {
		return [];
	}

	return $trafficgeniuspro_account;

} // trafficgeniuspro_account()

function trafficgeniuspro_create_post($data, $user_id) {
	try {

		global $trafficgeniuspro_account_option_name;
		//validate
		$trafficgeniuspro_account = get_option($trafficgeniuspro_account_option_name);

		if (!$trafficgeniuspro_account || $trafficgeniuspro_account['user_id'] != $user_id) {
			throw new Exception("Invalid wordpress user", 1);
		}

		$user = get_user_by('email', $data['wp_email']);
		$new_page = array(
			'post_title' 	=> wp_strip_all_tags($data['title']),
			'post_status' 	=> 'publish',
			'post_author' 	=> $user->ID,
			'post_type' 	=> 'post',
			'post_content' 	=> $data['body'],
			'post_name' 	=> $data['post_name']
		);

		$page_id = wp_insert_post($new_page);
		$page_link = get_page_link($page_id);
		return compact('page_id', 'page_link');

	} catch (Exception $e) {
		throw $e;
	}

}

function trafficgeniuspro_validate($email) {
	try {

		return  email_exists( $email ) ? true : false;

	} catch (Exception $e) {
		throw $e;
	}

}
