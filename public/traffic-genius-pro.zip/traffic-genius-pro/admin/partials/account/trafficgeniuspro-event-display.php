<?php

/**
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://trafficgeniuspro.com/
 * @since      1.0.0
 *
 * @package    trafficgeniuspro
 * @subpackage trafficgeniuspro/admin/partials
 */

?>
<script type="text/javascript">

</script>

<div id="trafficgeniuspro-account">
  <!-- Default panel contents -->
	<div class="form-row">
		<button type="submit" id="sync_account" class="btn btn-sm btn-info col-6" form="sync_pages">
	      Sync All Pages/Post
	    </button>
		<button type="submit" id="sync_account" class="btn btn-sm btn-danger col-6" form="logout_trafficgeniuspro">
	      Log out
	    </button>
	</div>
	  <form id="sync_pages" action="<?=esc_url(admin_url('admin-post.php'));?>" method="post" role="form" id="form-trafficgeniuspro-syn-account">
	    <input type="hidden" name="action" value="trafficgeniuspro_sync_pages">
	    <input type="hidden" name="type" value="update-or-create" id="type">
	    <input type="hidden" name="redirect_url" value="<?=$current_url?>">
	  </form>
	  <form id="logout_trafficgeniuspro" action="<?=esc_url(admin_url('admin-post.php'));?>" method="post" role="form" id="form-trafficgeniuspro-logout-account">
	    <input type="hidden" name="action" value="trafficgeniuspro_logout">
	    <input type="hidden" name="type" value="update-or-create" id="type">
	    <input type="hidden" name="redirect_url" value="<?=$current_url?>">
	  </form>
</div>
