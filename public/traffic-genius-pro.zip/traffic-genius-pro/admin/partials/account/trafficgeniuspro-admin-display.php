<?php

/**
 * Provide a admin slider area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://trafficgeniuspro.com/
 * @since      1.0.0
 *
 * @package    trafficgeniuspro
 * @subpackage trafficgeniuspro/admin/partials
 */

// get the current url, to be used to redirect later
global $wp;
$current_url = home_url(add_query_arg(null, null));

?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
</div>

<?php if (isset($_SESSION['trafficgeniuspro_message']) && isset($_SESSION['trafficgeniuspro_message']['message'])): ?>
	<div class="alert alert-<?=$_SESSION['trafficgeniuspro_message']['type'];?> alert-dismissible" role="alert">
	  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	  <strong><?=$_SESSION['trafficgeniuspro_message']['header'];?></strong> <?=$_SESSION['trafficgeniuspro_message']['message'];?>
	</div>
<?php unset($_SESSION['trafficgeniuspro_message']);endif;?>
<!-- include Setting display -->


<?php
// get the trafficgeniuspro account
$trafficgeniuspro_setting = get_trafficgeniuspro_account();

if (!$trafficgeniuspro_setting) {
	include_once 'trafficgeniuspro-setting-display.php';
} else {
	include_once 'trafficgeniuspro-event-display.php';
}
