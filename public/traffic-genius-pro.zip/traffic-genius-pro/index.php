<?php 
// Silence is golden