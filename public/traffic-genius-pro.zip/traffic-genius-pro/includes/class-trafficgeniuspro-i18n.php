<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       http://trafficgeniuspro.com/
 * @since      1.0.0
 *
 * @package    trafficgeniuspro
 * @subpackage trafficgeniuspro/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    trafficgeniuspro
 * @subpackage trafficgeniuspro/includes
 * @author     trafficgeniuspro <admin@trafficgeniuspro.com>
 */
class trafficgeniuspro_i18n {

	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'trafficgeniuspro',
			false,
			dirname(dirname(plugin_basename(__FILE__))) . '/languages/'
		);

	}

}
